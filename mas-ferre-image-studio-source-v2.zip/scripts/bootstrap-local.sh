#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "$0")/.." && pwd)"
cd "$project_dir"

if [[ ! -f .env ]]; then
  cp .env.example .env
fi

npm ci
python -m venv .venv
.venv/bin/pip install -r backend/requirements.txt

echo "Instalación terminada. Configura IMAGE_API_KEY en .env antes de iniciar."
