from celery import Celery
from ..config import get_settings

settings = get_settings()
celery_app = Celery("image_processor", broker=settings.celery_broker_url, backend=settings.celery_result_backend)
celery_app.conf.update(task_track_started=True, task_serializer="json", accept_content=["json"], result_serializer="json")
